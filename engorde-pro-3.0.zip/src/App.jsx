import React, { useState, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from "recharts";
import { motion } from "framer-motion";

export default function App() {
  const [animals, setAnimals] = useState(40);
  const [days, setDays] = useState(90);
  const [entryWeight, setEntryWeight] = useState(450);
  const [dailyGain, setDailyGain] = useState(1.1);
  const [salePriceKg, setSalePriceKg] = useState(2.6);
  const [purchasePriceKg, setPurchasePriceKg] = useState(2.2);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const saved = localStorage.getItem("engordeHistory");
    if (saved) setHistory(JSON.parse(saved));
  }, []);

  const finalWeight = entryWeight + dailyGain * days;
  const purchaseCost = entryWeight * purchasePriceKg * animals;
  const revenue = finalWeight * salePriceKg * animals;
  const profit = revenue - purchaseCost;

  const weightEvolution = Array.from({ length: days }, (_, i) => ({
    day: i + 1,
    weight: entryWeight + dailyGain * (i + 1)
  }));

  const saveScenario = () => {
    const record = {
      date: new Date().toLocaleDateString(),
      animals,
      days,
      profit
    };
    const updated = [...history, record];
    setHistory(updated);
    localStorage.setItem("engordeHistory", JSON.stringify(updated));
  };

  return (
    <div style={{ padding: 20, fontFamily: "Arial" }}>
      <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        Engorde Pro 3.0
      </motion.h1>

      <div>
        <label>Animales: </label>
        <input type="number" value={animals} onChange={e => setAnimals(+e.target.value)} />
      </div>

      <div>
        <label>Días: </label>
        <input type="number" value={days} onChange={e => setDays(+e.target.value)} />
      </div>

      <div>
        <label>Peso inicial (kg): </label>
        <input type="number" value={entryWeight} onChange={e => setEntryWeight(+e.target.value)} />
      </div>

      <div>
        <label>Ganancia diaria (kg): </label>
        <input type="number" step="0.1" value={dailyGain} onChange={e => setDailyGain(+e.target.value)} />
      </div>

      <div>
        <label>Precio venta USD/kg: </label>
        <input type="number" step="0.01" value={salePriceKg} onChange={e => setSalePriceKg(+e.target.value)} />
      </div>

      <div>
        <label>Precio compra USD/kg: </label>
        <input type="number" step="0.01" value={purchasePriceKg} onChange={e => setPurchasePriceKg(+e.target.value)} />
      </div>

      <h2>Resultados</h2>
      <p>Peso final: {finalWeight.toFixed(1)} kg</p>
      <p>Utilidad estimada: USD {profit.toFixed(0)}</p>

      <button onClick={saveScenario}>Guardar Escenario</button>

      <h2>Evolución de Peso</h2>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={weightEvolution}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="day" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="weight" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
